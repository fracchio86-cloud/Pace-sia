# Sacred Reflection — Android 0.1

Questo è il primo vero progetto Android del prototipo Sacred Reflection.

Tecnologia:
- Kotlin
- Android
- WebView con il prototipo locale come primo layer UI
- Gradle/Android Studio

Per aprirlo:
1. Installare Android Studio.
2. Aprire questa cartella come progetto.
3. Lasciare che Gradle sincronizzi le dipendenze.
4. Avviare su emulatore o dispositivo Android.
5. Per creare un APK usare Build > Build APK(s).

Nota: il progetto non contiene ancora il backend reale, le fonti liturgiche aggiornate, l'autenticazione, notifiche o il motore AI. Questi sono i prossimi livelli.


## Compilazione direttamente dal telefono
Il progetto include `.github/workflows/build-apk.yml`. Caricandolo in un repository GitHub, GitHub Actions può eseguire il build su una macchina virtuale e salvare l'APK come artifact. Non serve installare Android Studio sul telefono.
